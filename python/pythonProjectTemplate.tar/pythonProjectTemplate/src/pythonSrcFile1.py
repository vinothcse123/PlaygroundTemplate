import os

def mainFunc():
    print("Main function reached")

if __name__ == "__main__":
    mainFunc()
